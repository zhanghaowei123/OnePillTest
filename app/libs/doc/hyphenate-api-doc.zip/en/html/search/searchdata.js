var indexSectionsWithContent =
{
  0: "abcdefgijklmnoprstuv",
  1: "acdelmst",
  2: "abcdefgijklmoprstu",
  3: "acdefgimnprsuv",
  4: "v",
  5: "d"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "enumvalues",
  5: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Variables",
  4: "Enumerator",
  5: "Pages"
};

