var searchData=
[
  ['fetchchatroomannouncement',['fetchChatRoomAnnouncement',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_chat_room_manager.html#a7b9f6b24c9f73e39ff6b2d0041726897',1,'com::hyphenate::chat::EMChatRoomManager']]],
  ['fetchchatroomblacklist',['fetchChatRoomBlackList',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_chat_room_manager.html#a314857896294c00ffab070a94d87f740',1,'com::hyphenate::chat::EMChatRoomManager']]],
  ['fetchchatroomfromserver',['fetchChatRoomFromServer',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_chat_room_manager.html#abe65c32b2b9c856a70501418bea203ce',1,'com.hyphenate.chat.EMChatRoomManager.fetchChatRoomFromServer(String roomId)'],['../classcom_1_1hyphenate_1_1chat_1_1_e_m_chat_room_manager.html#a7576492c348f89ede237f3cc8ef0df86',1,'com.hyphenate.chat.EMChatRoomManager.fetchChatRoomFromServer(String roomId, boolean fetchMembers)']]],
  ['fetchchatroommembers',['fetchChatRoomMembers',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_chat_room_manager.html#ad7469b46a789d9a5d664646822dd6f9f',1,'com::hyphenate::chat::EMChatRoomManager']]],
  ['fetchchatroommutelist',['fetchChatRoomMuteList',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_chat_room_manager.html#adcc8a2cf7b46380e4efa050b4180a48a',1,'com::hyphenate::chat::EMChatRoomManager']]],
  ['fetchgroupannouncement',['fetchGroupAnnouncement',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_group_manager.html#a2feaa7ca0c92753499a46882283394ec',1,'com::hyphenate::chat::EMGroupManager']]],
  ['fetchgroupblacklist',['fetchGroupBlackList',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_group_manager.html#a06a2d5b74dfa76cdc77f8b9f06edf059',1,'com::hyphenate::chat::EMGroupManager']]],
  ['fetchgroupmembers',['fetchGroupMembers',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_group_manager.html#aa7b80f6795a6273e83018abb124968e1',1,'com::hyphenate::chat::EMGroupManager']]],
  ['fetchgroupmutelist',['fetchGroupMuteList',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_group_manager.html#a6703905ab2cc1cf43f93df876a472bd4',1,'com::hyphenate::chat::EMGroupManager']]],
  ['fetchgroupreadacks',['fetchGroupReadAcks',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_chat_manager.html#ae3354bbcf75038b35749df8824040b12',1,'com::hyphenate::chat::EMChatManager']]],
  ['fetchgroupsharedfilelist',['fetchGroupSharedFileList',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_group_manager.html#af4c8b35422fe021ba056d7421f7c19cd',1,'com::hyphenate::chat::EMGroupManager']]],
  ['fetchhistorymessages',['fetchHistoryMessages',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_chat_manager.html#a3b7353be09d9728e029d403e4bb7ee8c',1,'com::hyphenate::chat::EMChatManager']]],
  ['fetchpublicchatroomsfromserver',['fetchPublicChatRoomsFromServer',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_chat_room_manager.html#a14eff82a2de3497dbb953215ea1a7525',1,'com.hyphenate.chat.EMChatRoomManager.fetchPublicChatRoomsFromServer(int pageNum, int pageSize)'],['../classcom_1_1hyphenate_1_1chat_1_1_e_m_chat_room_manager.html#a736a13beebf61bd5ccca2695a3fc9cd9',1,'com.hyphenate.chat.EMChatRoomManager.fetchPublicChatRoomsFromServer(int pageSize, String cursor)']]],
  ['file_5fdelete_5ffailed',['FILE_DELETE_FAILED',['../classcom_1_1hyphenate_1_1_e_m_error.html#a62a0b701ddfeff5b28cf5cf2fa1f090a',1,'com::hyphenate::EMError']]],
  ['file_5fdownload_5ffailed',['FILE_DOWNLOAD_FAILED',['../classcom_1_1hyphenate_1_1_e_m_error.html#a0ed081a4d17b21982d4427da8dff8ecb',1,'com::hyphenate::EMError']]],
  ['file_5finvalid',['FILE_INVALID',['../classcom_1_1hyphenate_1_1_e_m_error.html#a9a2d473a2ef681dc3d27a7b5a74cd006',1,'com::hyphenate::EMError']]],
  ['file_5fnot_5ffound',['FILE_NOT_FOUND',['../classcom_1_1hyphenate_1_1_e_m_error.html#a789d29bfbc18af52b711103af9e2a2d3',1,'com::hyphenate::EMError']]],
  ['file_5ftoo_5flarge',['FILE_TOO_LARGE',['../classcom_1_1hyphenate_1_1_e_m_error.html#a08657b1c59175bb226403244d6409307',1,'com::hyphenate::EMError']]],
  ['file_5fupload_5ffailed',['FILE_UPLOAD_FAILED',['../classcom_1_1hyphenate_1_1_e_m_error.html#ad2311cd2907213d8df4d3292ef6aa296',1,'com::hyphenate::EMError']]]
];
